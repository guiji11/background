import request from '@/utils/request';
import store from '@/store'

const func = {
  getDeviceList:get_device_list,
  manageDevice:manage_device,
  getStatis:get_statis,
  getSuspend:get_suspend,
  setCountry:set_country,
  getConfig:get_config,
  setConfig:set_config,
  manageIp:manage_ip,
  getIpList:get_ip_list,
  getAccStat:get_acc_stat,
  setTaskType:set_task_type,
}

function get_device_list() {
  return request({
    url: store.getters.baseUrl+"fbapi/get_all_dev",                   
    method: 'get',
  })
}

function manage_device(data) {
  return request({
    url: store.getters.baseUrl+"fbapi/reg_banned",              
    method: 'post',
    data,
  })
}

function get_statis(data){
  return request({
    url: store.getters.baseUrl+"fbapi/get_reg_history",              
    method: 'post',
    data,
  })
}

function get_suspend(data){
  return request({
    url: store.getters.baseUrl+"fbapi/get_suspend_acc",              
    method: 'post',
    data,
  })
}

function set_country(data){
  return request({
    url: store.getters.baseUrl+"fbapi/set_dev_proxy_country",              
    method: 'post',
    data,
  })
}

function set_config(data){
  return request({
    url: store.getters.baseUrl+"fbapi/set_config",              
    method: 'post',
    data,
  })
}

function get_config(){
  return request({
    url: store.getters.baseUrl+"fbapi/get_config",              
    method: 'get',
  })
}

function manage_ip(data){
  return request({
    url: store.getters.baseUrl+"fbapi/update_proxy_ip_blacklist",              
    method: 'post',
    data,
  })
}

function get_ip_list(){
  return request({
    url: store.getters.baseUrl+"fbapi/get_proxy_ip_blacklist",              
    method: 'get',
  })
}

function get_acc_stat(){
  return request({
    url: store.getters.baseUrl+"fbapi/get_acc_stat",              
    method: 'get',
  })
}

function set_task_type(data){
  return request({
    url: store.getters.baseUrl+"fbapi/set_dev_task_type",              
    method: 'post',
    data,
  })
}

export default func
