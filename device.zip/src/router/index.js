import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)
const layout = () => import('@/page/layout/index');
const home = () => import('@/page/home/index');
const suspend = () => import('@/page/suspend/index');
const register = () => import('@/page/register/index');
const blacklist = () => import('@/page/blacklist/index');

const routes = [
	{
		path: '/',
		component: layout,
		name: 'Layout',
		children: [{
			path: '/home',
			name: 'Home',
			component: home,
			meta: ['设备列表'],
		},{
			path: '/suspend',
			name: 'Suspend',
			component: suspend,
			meta: ['封号记录'],
		},{
			path: '/register',
			name: 'Register',
			component: register,
			meta: ['注册历史'],
		},{
			path: '/blacklist',
			name: 'Blacklist',
			component: blacklist,
			meta: ['黑名单'],
		}]
	},
]

export default new Router({
	routes,
})
