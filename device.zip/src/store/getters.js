const getters = {
	baseUrl:state => state.data.baseUrl,
	messageUrl:state => state.data.messageUrl,
}
export default getters
