<template>
	<el-dialog
	title="设置任务"
	:visible.sync="currentIndex"
	@close ="callback(false)"
	destroy-on-close
	append-to-body
	:close-on-click-modal="false"
	class="list-border"
	center>
		<div class="list">
			<div class="item">
				<font>选择任务类型 : </font>
				<el-select v-model="curTask" class="select-border" >
					<el-option
						v-for="item in dataList"
						:key="item.task_type"
						:label="item.name"
						:value="item.task_type" >
					</el-option>
				</el-select>
			</div>
		</div>
		<span slot="footer" class="dialog-footer">
			<el-button type="primary"  @click.native.prevent="complete()">确 定</el-button>
		</span>
	</el-dialog>
</template>

<script>
import home from '@/api/home';
export default {
	data:function(){
		return{
			currentIndex:this.dialogVisible,
			dataList:[{"task_type":0,"name":"所有任务"},{"task_type":1,"name":"注册任务"},{"task_type":3,"name":"养号任务"},{"task_type":-1,"name":"禁止任务"}],
			curTask:'0',
		}
	},
	props:{
		info: {
		  type: Object,
		  required: true
		},
		dialogVisible: {
		  type: Boolean,
		  required: true
		},
	},
	watch:{
		dialogVisible:function(data){//监听属性变化
			this.currentIndex = data;
			this.curTask = this.info.task_type || 0;
		},
	},
	methods: {
		async complete(){
			var req = {
				"did":this.info.did,
				"task_type":Number(this.curTask),
			}
			const data = await home.setTaskType(JSON.stringify(req));
			if ( data.rtn == 0 ){
				this.callback(true);
			}else {
				this.$message({
					message: data.msg,
					center: true,
					type: 'error',
					duration: 3 * 1000
				})
			}
		},
		callback(data){
			this.$emit('changeStatus',data);	
			this.currentIndex = false;
		},
	}	
}			
</script>

<style lang="less" scoped>
	.list-border {                        
		/deep/ .el-dialog {
			width: 540px;
			height: 360px;
		}	
		/deep/ .el-input__inner{
			height: 38px;
			padding-left: 10px;
			line-height: 38px;
			color: #74788d;
		}	
		/deep/ .el-dialog--center .el-dialog__footer .el-button--primary,
		/deep/ .el-dialog--center .el-dialog__footer{
			width: 280px;
			height: 48px;
		}
		/deep/ .el-input{
			width:auto;
		}
    }
    .list{
		position: relative;
		margin-left: 130px;
		margin-top: 25px;
		width: 410px;
		height: 180px;
    	.item{
    		position:relative;
    		margin-top: 55px;
		    width: 280px;
			height: 38px;
			font{
				position:absolute;
				margin-left: 0px;
				z-index: 1;
				line-height: 38px;
				font-size: 12px;
				font-weight: 500;
				font-stretch: normal;
				letter-spacing: 0.36px;
			}
			.select-border{
				margin-left: 87px;
				width: 195px;
				color: #74788d;
			}
    	}
    }
</style>
