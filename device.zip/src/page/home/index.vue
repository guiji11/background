<template>
    <div class="fillcontain">
		<h2 class="title">设备列表</h2>
		<div class="table-title">
			<div class="table-item">
				<font class="title">养号冻结时长（分钟） ：</font>
				<el-input v-model="freeze" type="text" />
				<font class="title">养号间隔时长（分钟） ：</font>
				<el-input v-model="interval" type="text" />
				<font class="title">IP使用间隔（分钟） ：</font>
				<el-input v-model="ip" type="text" />
				<el-button class="create-mess-btn" @click.native.prevent="setConfig()">保存</el-button>
			</div>
		</div>
		<div class="list">
			<div class="table-content">
				<el-table
					v-loading="listLoading"
					height="100%"
					element-loading-text="Loading"
					:data="dataList"
					tooltip-effect="dark">
					<el-table-column
						prop="did"
					    label="设备ID">
					</el-table-column>
					<el-table-column
					    label="国家">
						<template scope="scope">
							<span>{{scope.row.country?scope.row.country:'--'}}</span>
						</template>
					</el-table-column>
					<el-table-column
					    label="系统版本">
						<template scope="scope">
							<span>{{scope.row.version?scope.row.version:'--'}}</span>
						</template>
					</el-table-column>
					<el-table-column
						prop="task_name"
					    label="任务类型">
					</el-table-column>
					<el-table-column
					    label="是否在线">
						<template scope="scope">
							<span :style="scope.row.online==1?'color:#3092fc':''">{{scope.row.online==1?'在线':'离线'}}</span>
						</template>
					</el-table-column>
					<el-table-column
					    label="设备状态">
						<template scope="scope">
							<span>{{scope.row.status==1?'忙碌':'空闲'}}</span>
						</template>
					</el-table-column>
					<el-table-column
						width="210px"
					    label="操作">
					    <template scope="scope">
							<button class="check-info" @click="setCountry(scope.row)">设置国家</button>
							<button class="check-info margin" @click="setTaskType(scope.row)">设置任务</button>
						</template>
					</el-table-column>
				</el-table>
			</div>
			<div class="table-pagination">
				<el-pagination
					@current-change="handleCurrentChange"
					:current-page.sync="currentPage"
					:page-size="pageSize"
					background
					layout="prev, pager, next"
					:page-count="pageTotal">
				</el-pagination>
			</div>
		</div>
		<set-country :did="curDid" :curCountry="curCountry" :dialogVisible="showCountry" @changeStatus="closeDialog"></set-country>
		<set-tasktype :info="curObj" :dialogVisible="showTaskType" @changeStatus="closeDialog"></set-tasktype>
    </div>
</template>

<script>
	import SetCountry from '@/components/SetCountry';
	import SetTasktype from '@/components/SetTasktype';
	import home from '@/api/home';
    export default {
        data(){
            return {
				listLoading:false,
				currentPage:1,
				pageSize:100,
				pageTotal:1,
				dataList:[],
				curDid:"",
				curCountry:"",
				curObj:{},
				showCountry:false,
				showTaskType:false,
				interval:0,
				freeze:0,
				ip:0,
            }
		},
		components: {
			SetCountry,
			SetTasktype
		},
		activated(){
			this.getDeviceList();
			this.getConfig();
		},
        methods: {
			handleCurrentChange(val){                         
				this.currentPage = val;
			},
			async setConfig(){
				var req = {
					"raise_freeze_min":Number(this.freeze),
					"raise_interval_min":Number(this.interval),
					"proxy_ip_use_interval":Number(this.ip),
				}
				const data = await home.setConfig(req);
				if ( data.rtn == 0 ){
						this.$message({
						message: "success",
						center: true,
						type: 'success',
						duration: 3 * 1000
					});
				}else {
					this.$message({
						message: data.msg,
						center: true,
						type: 'error',
						duration: 3 * 1000
					});
				}
			},
			async getConfig(){
				const data = await home.getConfig();
				if ( data.rtn == 0 ){
					this.freeze = data.data.raise_freeze_min || 0;
					this.interval = data.data.raise_interval_min || 0;
					this.ip = data.data.proxy_ip_use_interval || 0;
				}else {
					this.$message({
						message: data.msg,
						center: true,
						type: 'error',
						duration: 3 * 1000
					});
				}
			},
            async getDeviceList(){
				const data = await home.getDeviceList();
				if ( data.rtn == 0 ){
					const obj={
						"0":"所有任务",
						"1":"注册任务",
						"3":"养号任务",
						"-1":"禁止任务",
					}
					var list = data.data.list || [];
					list.sort(function(a,b){return b.online - a.online;});
					for (var i=0; i<list.length; i++){
						this.$set(list[i], "task_name", obj[list[i].task_type]);
					}
					this.dataList = list;
				}else {
					this.$message({
						message: data.msg,
						center: true,
						type: 'error',
						duration: 3 * 1000
					});
				}
			},
			setCountry(obj){
				this.curDid = obj.did;
				this.curCountry = obj.country;
				this.curObj = obj;
				this.showCountry = true;
			},
			setTaskType(obj){
				this.curObj = obj;
				this.showTaskType = true;
			},
			closeDialog(data){
				this.showCountry = false;
				this.showTaskType = false;
				if ( data ){
					this.getDeviceList();
				}
			}
        },
    }
</script>

<style lang="less" scoped>
.title{
	position:relative;
	margin-left: 19px;
	padding-top: 15px;
	font-size: 12px;	
	color: #34404b;
}
.create-mess-btn{
    margin-left: 25px;
    width: 70px;
    height: 34px;
    background-color: #7a9e9f;
    border-radius: 4px;
    color: #ffffff;
}
.table-title{
	position: relative;
	margin-top: 10px;
    left: 0px;
    right: 320px;
    height: 34px;
	.table-item{
		margin-right: 21px;
		float:left;
		.title{
			position: relative;
			margin-left: 19px;
			padding-top: 15px;
			margin-right: 9px;
			font-weight: 500;
			font-size: 12px;
			font-stretch: normal;
			letter-spacing: 0.36px;
			color: #595d6e;
		}
		.select-border{
			width: 136px;
			height: 34px;
			background-color: #ffffff;
			border-radius: 4px;
		}
	}
}
.list{
	position: absolute;
	left:19px;
	right:19px;
	top:90px;
	bottom:20px;
	border-radius: 4px;
	.table-content{
		position: absolute;
		width:100%;
		top: 0px;
		bottom: 40px;
		box-shadow: 0px 3px 4px 0px rgba(0, 0, 0, 0.04);
		border-radius: 4px;
		.check-info{
			position: relative;
			padding: 4px 13px;
			background-color: #ffffff;
			border: solid 1px #e7e7e7;
			border-radius: 19px;
			font-size: 12px;
			color: #828f9c;
			cursor:pointer;
		}
		.margin{
			margin-left: 10px;
		}
	}
	.table-pagination /deep/{
		position: absolute;
		bottom: 0px;
		left: 0px;
		right: 0px;
		margin-top: 5px;
		text-align: center;
		height: 27px;
		.el-pagination{
			padding: 0 0;
		}
	}
}
/deep/.el-input{
	width:80px;
}
</style>
