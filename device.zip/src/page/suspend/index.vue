<template>
    <div class="fillcontain">
		<h2 class="title">封号记录 ( {{total}} )</h2>
		<div class="table-title">
			<el-radio v-model="radio" label="0" @change="changeType()" :disabled="maildi">封号时间</el-radio>
			<el-radio v-model="radio" label="1" @change="changeType()" :disabled="fbdi">注册时间</el-radio>
			<div class="table-item">
				<el-date-picker
					v-model="dateArr"
					@change = changeTime
					value-format="yyyy-MM-dd"
					type="date"
					placeholder="选择日期">
				</el-date-picker>
			</div>
		</div>
		<div class="list">
			<div class="table-content">
				<el-table
					v-loading="listLoading"
					height="100%"
					element-loading-text="Loading"
					:data="dataList"
					tooltip-effect="dark">
					<el-table-column
						prop="sus_time"
					    label="封号时间">
					</el-table-column>
					<el-table-column
						prop="reg_time"
					    label="注册时间">
					</el-table-column>
					<el-table-column
						prop="acc"
					    label="账号">
					</el-table-column>
					<el-table-column
						prop="errmsg"
					    label="原因">
					</el-table-column>
					<el-table-column
					    label="信息">
						<template scope="scope">
							<el-tooltip effect="dark" :content="scope.row.proxy_info" placement="top">
								<div>{{scope.row.proxy_info?scope.row.proxy_info:'--'}}</div>
							</el-tooltip>
						</template>
					</el-table-column>
				</el-table>
			</div>
			<div class="table-pagination">
				<el-pagination
					@current-change="handleCurrentChange"
					:current-page.sync="currentPage"
					:page-size="pageSize"
					background
					layout="prev, pager, next"
					:page-count="pageTotal">
				</el-pagination>
			</div>
		</div>
    </div>
</template>

<script>
	import home from '@/api/home';
	import moment from 'moment';
    export default {
		name:"DataStatistics",
        data(){
            return {
				listLoading:true,
				radio:'0',
				myChartLine:'',
				currentPage:1,
				pageSize:100,
				pageTotal:1,
				dataList:[],
				dateArr:'',
				total:0,
            }
		},
		mounted(){
			this.dateArr = moment(new Date()).format('YYYY-MM-DD');
		},
		activated(){
			this.changeTime();
		},
        methods: {
			changeType(){
				this.getStatisticsList();
			},
			handleCurrentChange(val){                           
				this.currentPage = val;
			},
			getLocalTime(nS) { 
				return new Date(parseInt(nS) * 1000);  
			},
			changeTime(){
				this.getStatisticsList();
			},
            async getStatisticsList(){
              	var req = {
					"date":this.dateArr,
					"type":Number(this.radio)
				}
				const data = await home.getSuspend(JSON.stringify(req));
				this.listLoading = false;
				if ( data.rtn ==0 ){
					var list = data.data.list || [];
					for ( var i=0; i<list.length;i++ ){
						this.$set(list[i],"reg_time",moment(list[i].reg_ts*1000).format('YYYY-MM-DD HH:mm'));
						this.$set(list[i],"sus_time",moment(list[i].suspend_ts*1000).format('YYYY-MM-DD HH:mm'));
						if ( list[i].proxy_info ){
							list[i].proxy_info = JSON.stringify(list[i].proxy_info);
						}
					}
					this.dataList = list;
					this.total = this.dataList.length;
				}else {
					this.$message({
						message: data.msg,
						center: true,
						type: 'error',
						duration: 3 * 1000
					});
				}
			},
        },
    }
</script>

<style lang="less" scoped>
.return{
    position: absolute;
    margin-left: 18px;
    padding-top: 11px;
    height: 24px;
    width: 24px;
    cursor: pointer;
}
.title{
	position:relative;
	margin-left: 19px;
	padding-top: 15px;
	font-size: 12px;	
	color: #34404b;
}
.echart{
	position: relative;
	margin: 15px 19px;
    display: flex;
    justify-content:space-between;
    cursor: default;
	height: 350px;
	.list-chart{
		position: relative;
		padding-top: 10px;
		width:100%;
		height: 340px;
		background-color: #172b4d;
		border-radius: 6px;
		overflow: hidden;
		box-shadow: 0 6px 10px -4px rgba(0, 0, 0, 0.15);
	}
}
.table-title{
    position: relative;
	left: 19px;
	margin-top: 15px;
    right: 320px;
    height: 34px;
	.table-item{
		position: absolute;
		top: -10px;
		margin-left: 210px;
		.title{
			position: relative;
			margin-left: 19px;
			padding-top: 15px;
			margin-right: 9px;
			font-weight: 500;
			font-size: 12px;
			font-stretch: normal;
			letter-spacing: 0.36px;
			color: #595d6e;
		}
		.select-border{
			width: 136px;
			height: 34px;
			background-color: #ffffff;
			border-radius: 4px;
		}
	}
}
.list {
	position: absolute;
	left:19px;
	right:19px;
	top:85px;
	bottom:20px;
	border-radius: 4px;
	.table-content{
		position: absolute;
		width:100%;
		top: 0px;
		bottom: 40px;
		box-shadow: 0px 3px 4px 0px rgba(0, 0, 0, 0.04);
		border-radius: 4px;
		.check-info{
			position: relative;
			padding: 4px 13px;
			background-color: #ffffff;
			border: solid 1px #e7e7e7;
			border-radius: 19px;
			font-size: 12px;
			color: #828f9c;
			cursor:pointer;
		}
		.table-item{
			padding-left: 0px;
			margin-right: 21px;
			float:left;
			.title{
				position: relative;
				margin-left: 0px;
				padding-top: 15px;
				margin-right: 0px;
				font-weight: 500;
				font-size: 12px;
				font-stretch: normal;
				letter-spacing: 0.36px;
				color: #595d6e;
			}
			.select-border {
				padding-left: 10px;
				width: 116px;
				height: 34px;
				background-color: #ffffff;
				border-radius: 4px;
			}
		}
	}
	.table-pagination /deep/{
		position: absolute;
		bottom: 0px;
		left: 0px;
		right: 0px;
		margin-top: 5px;
		text-align: center;
		height: 27px;
		.el-pagination{
			padding: 0 0;
		}
	}
}
/deep/ .el-input{
	width: 140px;
}
</style>
