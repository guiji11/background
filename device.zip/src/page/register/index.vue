<template>
    <div class="fillcontain">
		<h2 class="title">注册历史</h2>
		<div class="echart">
			<div class="card-list">
				<div class="card-item" v-for="item in chanList" :key="item.acc_chan">
					<div class="card-border margin-right">
						<div class="card-content">
							<svg-icon :iconClass="item.acc_chan==1?'acc-count':'acc-count-other'" class="card-icon"/>
							<div class="card-value">{{item.alive}}</div>
						</div>
						<div class="card-name">{{item.acc_chan==1?'注册渠道-存活数':'旧号导入渠道-存活数'}}</div>
					</div>
					<div class="card-border">
						<div class="card-content">
							<svg-icon :iconClass="item.acc_chan==1?'acc-block':'acc-block-other'" class="card-icon"/>
							<div class="card-value">{{item.suspend}}</div>
						</div>
						<div class="card-name">{{item.acc_chan==1?'注册渠道-封号数':'旧号导入渠道-封号数'}}</div>
					</div>
				</div>
			</div>
			<div class="list-chart" id="echart_line"></div>
		</div>
		<div class="table-title">
			<div class="table-item">
				<font class="title">日期选择 ：</font>
				<el-date-picker
					v-model="dateArr"
					@change = changeTime
					value-format="yyyy-MM-dd"
					type="daterange"
					range-separator="至"
					start-placeholder="开始日期"
					end-placeholder="结束日期">
				</el-date-picker>
			</div>
		</div>
		<div class="list">
			<div class="table-content">
				<el-table
					v-loading="listLoading"
					height="100%"
					element-loading-text="Loading"
					:data="dataList"
					tooltip-effect="dark">
					<el-table-column
						prop="date"
					    label="时间">
					</el-table-column>
					<el-table-column
						prop="reg_num"
					    label="注册数">
					</el-table-column>
					<el-table-column
						prop="suspend_num"
					    label="封号数">
					</el-table-column>
					<el-table-column
						prop="reg_suspend_num"
					    label="当日注册封号数">
					</el-table-column>
				</el-table>
			</div>
			<div class="table-pagination">
				<el-pagination
					@current-change="handleCurrentChange"
					:current-page.sync="currentPage"
					:page-size="pageSize"
					background
					layout="prev, pager, next"
					:page-count="pageTotal">
				</el-pagination>
			</div>
		</div>
    </div>
</template>

<script>
	import home from '@/api/home';
	import echarts from 'echarts';
	import moment from 'moment';
    export default {
		name:"DataStatistics",
        data(){
            return {
				listLoading:true,
				myChartLine:'',
				currentPage:1,
				pageSize:100,
				pageTotal:1,
				dataList:[],
				taskTime:[],
				reg_num:[],
				suspend_num:[],
				dateArr:'',
				begin:"",
				end:"",
				chanList:[],
            }
		},
		mounted(){
			var start = this.getLocalTime(new Date().getTime()/1000-60*60*24*6);
			this.dateArr=[moment(start).format('YYYY-MM-DD'),moment(new Date()).format('YYYY-MM-DD')];
		},
		activated(){
			this.changeTime();
			this.getAccStat();
		},
        methods: {
			handleCurrentChange(val){                           
				this.currentPage = val;
			},
			getLocalTime(nS) { 
				return new Date(parseInt(nS) * 1000);  
			},
			changeTime(){
				this.begin = this.dateArr[0];
				this.end = this.dateArr[1];
				this.getStatisticsList();
			},
            async getStatisticsList(){
              	var req = {
					"from":this.begin,
					"to":this.end
				}
				const data = await home.getStatis(JSON.stringify(req));
				this.listLoading = false;
				if ( data.rtn ==0 ){
					this.taskTime = [];
					this.reg_num = [];
					this.suspend_num = [];
					var list = data.data.list || [];
					for ( var i=0; i<list.length;i++ ){
						this.setEchartData(list[i]);
					}
					this.dataList = list;
					this.initChart();
				}else {
					this.$message({
						message: data.msg,
						center: true,
						type: 'error',
						duration: 3 * 1000
					});
				}
			},
			async getAccStat(){
				const data = await home.getAccStat();
				if ( data.rtn ==0 ){
					var list = data.data.list || [];
					list.sort(function(a,b){return a.acc_chan - b.acc_chan;});
					this.chanList = list;
				}
			},
			setEchartData(obj){
				this.taskTime.unshift(obj.date);
				this.reg_num.unshift(obj.reg_num);
				this.suspend_num.unshift(obj.suspend_num);
			},	
			initChart(){
				this.myChartLine = echarts.init(document.getElementById('echart_line'));
				var lineArr=[
					{"name":"注册数","width":3,"type":"line","color":"#5e72e4","data":this.reg_num},
					{"name":"封号数","width":3,"type":"line","color":"#a0650b","data":this.suspend_num},
				];
				this.lineChart(this.myChartLine, this.taskTime, lineArr);
			},
			lineChart(show, dataX, dataY){                                                    
				this.lineDataStyle(dataY);
				show.setOption({
					tooltip: {
						trigger: 'axis'
					},
					legend: {
						textStyle: {
							fontSize: 12,
							color: '#ffffff'
						},
						data:['注册数','封号数']
					},                                                                         //图例名
					grid: {                                                                   //折线图位置                                                  
						left: "5%",
						bottom: "3%",
						top: "12%",
						right:"5%",
						containLabel: false
					},
					xAxis: {                                                                  //横坐标轴
						type: "category",
						boundaryGap: false,
						data: dataX,
						show:false,                                                           //隐藏坐标轴
					},
					yAxis: [{                                                                 //纵坐标轴
						type: 'value',
						show:false,
					}],
					series: this.series
				});
			},
			lineDataStyle(arr){
				this.series = [];
				for ( var i=0; i<arr.length;i++ ){
					var obj = {
						type: arr[i].type,
						name:arr[i].name,
						barWidth:15,
						symbol: 'none',                                                       //拐点标记隐藏掉
						smooth:true,                                                          //拐点平滑
						itemStyle: {
							normal: {
								color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [{
									offset: 0,
									color: arr[i].color
								}]),
								lineStyle: { width:arr[i].width }
							},
						},		
						data:arr[i].data,					
					};
					this.series.push(obj);
				}
			},
        },
    }
</script>

<style lang="less" scoped>
.return{
    position: absolute;
    margin-left: 18px;
    padding-top: 11px;
    height: 24px;
    width: 24px;
    cursor: pointer;
}
.title{
	position:relative;
	margin-left: 19px;
	padding-top: 15px;
	font-size: 12px;	
	color: #34404b;
}
.echart{
	position: relative;
	margin: 15px 19px;
    display: flex;
    justify-content:space-between;
    cursor: default;
	height: 330px;
	.list-chart{
		position: relative;
		padding-top: 10px;
		width:49%;
		height: 320px;
		background-color: #172b4d;
		border-radius: 6px;
		overflow: hidden;
		box-shadow: 0 6px 10px -4px rgba(0, 0, 0, 0.15);
	}
}
.card-list{
	position: relative;
	padding-top: 10px;
    cursor: default;
	height: 320px;
	width:49%;
	.card-item{
		display: flex;
		width:100%;
		height: 138px;
    	margin-bottom: 33px;
		.card-border{
			position:relative;
			width: 49%;
			height: 100%;
			background-color: #ffffff;
			box-shadow: 0 6px 10px -4px rgba(0,0,0,.15);
			border-radius: 6px;
			.card-content{
				position:relative;
				border-bottom: 1px solid #eeeeee;
				padding-top: 15px;
				width: 90%;
				margin-left: auto;
				margin-right: auto;
				height: 77px;
				.card-value{
					position: absolute;
					top: 35px;
					right: 0px;
					height: 30px;
					line-height: 30px;
					color: #74788d;
					font-size: 30px;
					white-space: nowrap;
					overflow: hidden;
					text-overflow: ellipsis;
				}
				.card-icon{
					margin-left: 10px;
					color: #768492;
					height:42px;
					width:42px;
					padding-top: 15px;
				}
			}
			.card-name{
				margin-left: auto;
				margin-right: auto;
				padding-top: 12px;
				color: #a49e93;
				font-size: 14px;
				font-weight: 500;
				width: 90%;
			}
		}
	}
	.mess-detail{
		position: absolute;
		right: 4%;
		width: 25px;
		height: 22px;
		bottom: 12px;
		cursor: pointer;
	}
	.margin-right{
		margin-right: 30px;
	}
}
.table-title{
    position: relative;
    left: 0px;
    right: 320px;
    height: 34px;
	.table-item{
		margin-right: 21px;
		float:left;
		.title{
			position: relative;
			margin-left: 19px;
			padding-top: 15px;
			margin-right: 9px;
			font-weight: 500;
			font-size: 12px;
			font-stretch: normal;
			letter-spacing: 0.36px;
			color: #595d6e;
		}
		.select-border{
			width: 136px;
			height: 34px;
			background-color: #ffffff;
			border-radius: 4px;
		}
	}
}
.list {
	position: absolute;
	left:19px;
	right:19px;
	top:440px;
	bottom:20px;
	border-radius: 4px;
	.table-content{
		position: absolute;
		width:100%;
		top: 0px;
		bottom: 40px;
		box-shadow: 0px 3px 4px 0px rgba(0, 0, 0, 0.04);
		border-radius: 4px;
		.check-info{
			position: relative;
			padding: 4px 13px;
			background-color: #ffffff;
			border: solid 1px #e7e7e7;
			border-radius: 19px;
			font-size: 12px;
			color: #828f9c;
			cursor:pointer;
		}
		.table-item{
			padding-left: 0px;
			margin-right: 21px;
			float:left;
			.title{
				position: relative;
				margin-left: 0px;
				padding-top: 15px;
				margin-right: 0px;
				font-weight: 500;
				font-size: 12px;
				font-stretch: normal;
				letter-spacing: 0.36px;
				color: #595d6e;
			}
			.select-border {
				padding-left: 10px;
				width: 116px;
				height: 34px;
				background-color: #ffffff;
				border-radius: 4px;
			}
		}
	}
	.table-pagination /deep/{
		position: absolute;
		bottom: 0px;
		left: 0px;
		right: 0px;
		margin-top: 5px;
		text-align: center;
		height: 27px;
		.el-pagination{
			padding: 0 0;
		}
	}
}
</style>
