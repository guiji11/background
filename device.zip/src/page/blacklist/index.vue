<template>
    <div class="fillcontain">
		<h2 class="title">IP管理</h2>
		<div class="table-title">
			<div class="table-item">
				<font class="title">添加IP黑名单 ：</font>
				<el-input v-model="addIp" type="text" @blur="manageIp()"/>
			</div>
		</div>
		<div class="list">
			<div class="table-content">
				<el-table
					v-loading="listLoading"
					height="100%"
					element-loading-text="Loading"
					:data="dataList"
					tooltip-effect="dark">
					<el-table-column
						prop="time"
					    label="时间">
					</el-table-column>
					<el-table-column
						prop="ip"
					    label="IP">
					</el-table-column>
					<el-table-column
					    label="状态">
						<template scope="scope">
							<span :style="scope.row.status==0?'color:#3092fc':''">{{scope.row.status==1?'已禁止':'已解封'}}</span>
						</template>
					</el-table-column>
					<el-table-column
						width="180px"
					    label="操作">
					    <template scope="scope">
							<button class="check-info" @click="removeIp(scope.row.ip)">移除</button>
							<button class="check-info margin" @click="manageIp(scope.row.ip,scope.row.status)">{{scope.row.status==1?'解封':'禁止'}}</button>
						</template>
					</el-table-column>
				</el-table>
			</div>
			<div class="table-pagination">
				<el-pagination
					@current-change="handleCurrentChange"
					:current-page.sync="currentPage"
					:page-size="pageSize"
					background
					layout="prev, pager, next"
					:page-count="pageTotal">
				</el-pagination>
			</div>
		</div>
    </div>
</template>

<script>
	import home from '@/api/home';
	import { MessageBox } from 'element-ui';
	import moment from 'moment';
    export default {
        data(){
            return {
				listLoading:false,
				currentPage:1,
				pageSize:100,
				pageTotal:1,
				dataList:[],
				addIp:"",
            }
		},
		activated(){
			this.getIpList();
		},
        methods: {
			handleCurrentChange(val){                         
				this.currentPage = val;
			},
            async getIpList(){
				const data = await home.getIpList();
				if ( data.rtn == 0 ){
					var list = data.data.list || [];
					list.sort(function(a,b){return a.status - b.status;});
					for ( var i=0; i<list.length;i++ ){
						this.$set(list[i],"time",moment(list[i].ts*1000).format('YYYY-MM-DD HH:mm'));
					}
					this.dataList = list;
				}else {
					this.$message({
						message: data.msg,
						center: true,
						type: 'error',
						duration: 3 * 1000
					});
				}
			},
			removeIp(ip){
				MessageBox.confirm('是否移除该黑名单？', '', {
				confirmButtonText: '确定',
				showCancelButton:false,
				type: 'warning'
				}).then(() => {
					this.manageIp(ip);
				});
			},
			async manageIp(ip, status){
				var opt = 2;
				if ( status == 0 ){
					opt = 1;
				}else if ( status == 1 ){
					opt = 3;
				}
				if ( !ip ){
					ip = this.addIp;
					opt = 1;
				}
				if ( !ip ){
					return;
				}
				var req = {
					"proxy_ip":ip,
					"opt":opt,
				}
				const data = await home.manageIp(JSON.stringify(req));
				if ( data.rtn == 0 ){
					this.getIpList();
					this.addIp = "";
				}else {
					this.$message({
						message: data.msg,
						center: true,
						type: 'error',
						duration: 3 * 1000
					});
				}
			},
        },
    }
</script>

<style lang="less" scoped>
.title{
	position:relative;
	margin-left: 19px;
	padding-top: 15px;
	font-size: 12px;	
	color: #34404b;
}
.create-mess-btn{
    margin-left: 25px;
    width: 70px;
    height: 34px;
    background-color: #7a9e9f;
    border-radius: 4px;
    color: #ffffff;
}
.table-title{
	position: relative;
	margin-top: 10px;
    left: 0px;
    right: 320px;
    height: 34px;
	.table-item{
		margin-right: 21px;
		float:left;
		.title{
			position: relative;
			margin-left: 19px;
			padding-top: 15px;
			margin-right: 9px;
			font-weight: 500;
			font-size: 12px;
			font-stretch: normal;
			letter-spacing: 0.36px;
			color: #595d6e;
		}
		.select-border{
			width: 136px;
			height: 34px;
			background-color: #ffffff;
			border-radius: 4px;
		}
	}
}
.list{
	position: absolute;
	left:19px;
	right:19px;
	top:90px;
	bottom:20px;
	border-radius: 4px;
	.table-content{
		position: absolute;
		width:100%;
		top: 0px;
		bottom: 40px;
		box-shadow: 0px 3px 4px 0px rgba(0, 0, 0, 0.04);
		border-radius: 4px;
		.check-info{
			position: relative;
			padding: 4px 13px;
			background-color: #ffffff;
			border: solid 1px #e7e7e7;
			border-radius: 19px;
			font-size: 12px;
			color: #828f9c;
			cursor:pointer;
		}
		.margin{
			margin-left: 10px;
		}
	}
	.table-pagination /deep/{
		position: absolute;
		bottom: 0px;
		left: 0px;
		right: 0px;
		margin-top: 5px;
		text-align: center;
		height: 27px;
		.el-pagination{
			padding: 0 0;
		}
	}
}
/deep/.el-input{
	width:140px;
}
</style>
